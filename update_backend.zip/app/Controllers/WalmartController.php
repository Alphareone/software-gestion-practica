<?php

/**
 * Módulo Walmart Chile Marketplace.
 * Rutas: /walmart/{metodo} (resueltas automáticamente por app/core/App.php).
 */
class WalmartController extends Controller {

    protected $baseRoute = '/walmart';

    protected function route($path = '') {
        return URLROOT . $this->baseRoute . $path;
    }

    protected function ensureCsrf() {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
    }

    protected function getConnections() {
        $connModel = new WalmartConnectionModel($this->db());
        $rows = $connModel->findAll();
        foreach ($rows as $row) {
            $row->token_ok = $row->token_expires_at && strtotime($row->token_expires_at . ' UTC') > time();
        }
        return $rows;
    }

    /** Valida método POST + token CSRF; redirige a adminstores si falla. */
    protected function requirePostCsrf() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . $this->route('/adminstores'));
            exit;
        }
        $csrf = $_POST['csrf_token'] ?? '';
        if (empty($csrf) || !hash_equals($_SESSION['csrf_token'] ?? '', $csrf)) {
            $_SESSION['error'] = 'Token inválido.';
            header('Location: ' . $this->route('/adminstores'));
            exit;
        }
    }

    // ── Páginas ──

    public function index() {
        $this->requireAuth();
        $this->ensureCsrf();

        $connModel = new WalmartConnectionModel($this->db());

        $page_title = 'Walmart - Panel';
        $page_description = 'Resumen de las tiendas Walmart Chile conectadas.';
        $current_nav = 'walmart';

        $data = [
            'csrf_token' => $_SESSION['csrf_token'],
            'connections' => $connModel->findActive(),
            'is_admin' => !empty($_SESSION['is_admin']),
            'dry_run' => WALMART_DRY_RUN,
        ];

        $view_content = __DIR__ . '/../Views/walmart/content-dashboard.php';
        require __DIR__ . '/../Views/layouts/app.php';
    }

    public function products() {
        $this->requireAuth();
        $this->ensureCsrf();

        $connModel = new WalmartConnectionModel($this->db());

        $page_title = 'Walmart - Productos';
        $page_description = 'Explora el catálogo sincronizado desde Walmart.';
        $current_nav = 'walmart-products';

        $data = [
            'csrf_token' => $_SESSION['csrf_token'],
            'connections' => $connModel->findActive(),
            'dry_run' => WALMART_DRY_RUN,
        ];

        $view_content = __DIR__ . '/../Views/walmart/content-products.php';
        require __DIR__ . '/../Views/layouts/app.php';
    }

    // ── JSON: métricas y productos ──

    public function metrics($id = null) {
        $this->requireAuth();
        header('Content-Type: application/json');

        if (empty($id) || !is_numeric($id)) {
            echo json_encode(['error' => 'ID no especificado.']);
            exit;
        }

        $db = $this->db();
        $conn = (new WalmartConnectionModel($db))->findById((int) $id);
        if (!$conn) {
            echo json_encode(['error' => 'Tienda no encontrada.']);
            exit;
        }
        if (!$conn->is_active) {
            echo json_encode(['total' => 0, 'published' => 0, 'low_stock' => 0]);
            exit;
        }

        $metrics = (new WalmartProductsCacheModel($db))->getMetrics((int) $id);
        $sync = (new WalmartSyncStatusModel($db))->get((int) $id);
        $metrics['store_id'] = (int) $id;
        $metrics['store_name'] = $conn->store_name;
        $metrics['sync_status'] = $sync->status ?? 'idle';
        $metrics['last_sync_at'] = $sync->last_sync_at ?? null;
        echo json_encode($metrics);
        exit;
    }

    public function productsData() {
        $this->requireAuth();
        header('Content-Type: application/json');

        $storeId = isset($_GET['store']) && is_numeric($_GET['store']) ? (int) $_GET['store'] : 0;
        if (!$storeId) {
            echo json_encode(['error' => 'Tienda no especificada.']);
            exit;
        }

        $page = isset($_GET['page']) && is_numeric($_GET['page']) ? max(1, (int) $_GET['page']) : 1;
        $limit = isset($_GET['limit']) && is_numeric($_GET['limit']) ? min(100, max(10, (int) $_GET['limit'])) : 50;
        $search = trim((string) ($_GET['q'] ?? ''));
        $status = trim((string) ($_GET['status'] ?? ''));

        $cache = new WalmartProductsCacheModel($this->db());
        echo json_encode($cache->getProducts($storeId, $page, $limit, $search, $status));
        exit;
    }

    // ── JSON: sincronización ──

    public function syncStatus() {
        $this->requireAuth();
        header('Content-Type: application/json');
        $sync = new WalmartSyncService($this->db());
        echo json_encode(['stores' => $sync->getAllStatuses()]);
        exit;
    }

    public function syncStart($id = null) {
        $this->requireAuth();
        header('Content-Type: application/json');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($id) || !is_numeric($id)) {
            echo json_encode(['ok' => false, 'error' => 'Petición inválida.']);
            exit;
        }
        $csrf = $_POST['csrf_token'] ?? '';
        if (empty($csrf) || !hash_equals($_SESSION['csrf_token'] ?? '', $csrf)) {
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'Token inválido.']);
            exit;
        }

        $sync = new WalmartSyncService($this->db());
        echo json_encode($sync->startFullSync((int) $id, (int) $_SESSION['user_id']));
        exit;
    }

    public function syncChunk($id = null) {
        $this->requireAuth();
        header('Content-Type: application/json');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($id) || !is_numeric($id)) {
            echo json_encode(['ok' => false, 'error' => 'Petición inválida.']);
            exit;
        }
        $csrf = $_POST['csrf_token'] ?? '';
        if (empty($csrf) || !hash_equals($_SESSION['csrf_token'] ?? '', $csrf)) {
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'Token inválido.']);
            exit;
        }

        $sync = new WalmartSyncService($this->db());
        echo json_encode($sync->processChunk((int) $id, (int) $_SESSION['user_id']));
        exit;
    }

    public function syncStop($id = null) {
        $this->requireAuth();
        header('Content-Type: application/json');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($id) || !is_numeric($id)) {
            echo json_encode(['ok' => false, 'error' => 'Petición inválida.']);
            exit;
        }
        $csrf = $_POST['csrf_token'] ?? '';
        if (empty($csrf) || !hash_equals($_SESSION['csrf_token'] ?? '', $csrf)) {
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'Token inválido.']);
            exit;
        }

        $sync = new WalmartSyncService($this->db());
        echo json_encode($sync->stopSync((int) $id));
        exit;
    }

    public function connect() {
        $this->requireAdmin();
        $this->ensureCsrf();

        $editId = isset($_GET['edit']) && is_numeric($_GET['edit']) ? (int) $_GET['edit'] : 0;
        $editConn = null;
        if ($editId) {
            $editConn = (new WalmartConnectionModel($this->db()))->findById($editId);
        }

        $page_title = 'Walmart - Conectar tienda';
        $page_description = 'Conecta una cuenta de vendedor de Walmart Chile.';
        $current_nav = 'walmart-admin';

        $data = [
            'csrf_token' => $_SESSION['csrf_token'],
            'edit' => $editConn,
            'default_base_url' => WALMART_API_BASE_URL,
            'dry_run' => WALMART_DRY_RUN,
        ];

        $view_content = __DIR__ . '/../Views/walmart/content-connect.php';
        require __DIR__ . '/../Views/layouts/app.php';
    }

    public function adminstores() {
        $this->requireAdmin();
        $this->ensureCsrf();

        $page_title = 'Walmart - Gestión de Tiendas';
        $page_description = 'Administra las cuentas de Walmart Chile conectadas.';
        $current_nav = 'walmart-admin';

        $data = [
            'csrf_token' => $_SESSION['csrf_token'],
            'connections' => $this->getConnections(),
            'dry_run' => WALMART_DRY_RUN,
        ];

        $view_content = __DIR__ . '/../Views/walmart/content-admin-stores.php';
        require __DIR__ . '/../Views/layouts/app.php';
    }

    // ── Gestión de conexiones (admin, POST + CSRF) ──

    public function saveConnection() {
        $this->requireAdmin();
        $this->requirePostCsrf();

        $editId = isset($_POST['edit_id']) && is_numeric($_POST['edit_id']) ? (int) $_POST['edit_id'] : 0;
        $storeName = trim((string) ($_POST['store_name'] ?? ''));
        $clientId = trim((string) ($_POST['client_id'] ?? ''));
        $clientSecret = trim((string) ($_POST['client_secret'] ?? ''));
        $channelType = trim((string) ($_POST['channel_type'] ?? ''));
        $apiBaseUrl = trim((string) ($_POST['api_base_url'] ?? '')) ?: WALMART_API_BASE_URL;

        $backTo = $this->route('/connect' . ($editId ? '?edit=' . $editId : ''));

        if ($storeName === '' || $clientId === '') {
            $_SESSION['error'] = 'Nombre de tienda y Client ID son obligatorios.';
            header('Location: ' . $backTo);
            exit;
        }
        if (!$editId && $clientSecret === '') {
            $_SESSION['error'] = 'El Client Secret es obligatorio.';
            header('Location: ' . $backTo);
            exit;
        }
        if (!preg_match('#^https://[a-z0-9.\-]+$#i', rtrim($apiBaseUrl, '/'))) {
            $_SESSION['error'] = 'La URL base de la API no es válida (debe ser https://...).';
            header('Location: ' . $backTo);
            exit;
        }
        $apiBaseUrl = rtrim($apiBaseUrl, '/');

        $db = $this->db();
        $connModel = new WalmartConnectionModel($db);

        // En edición sin secret nuevo se conserva el cifrado existente
        $existing = $editId ? $connModel->findById($editId) : null;
        if ($editId && !$existing) {
            $_SESSION['error'] = 'La conexión a editar no existe.';
            header('Location: ' . $this->route('/adminstores'));
            exit;
        }
        $secretPlain = $clientSecret !== ''
            ? $clientSecret
            : ($existing ? CryptoHelper::decrypt($existing->client_secret) : '');

        $auth = new WalmartAuthService($db);
        $test = $auth->testCredentials($clientId, $secretPlain, $apiBaseUrl, $channelType ?: null);
        if (!$test['ok']) {
            $_SESSION['error'] = 'No se guardó la conexión: ' . $test['error'];
            header('Location: ' . $backTo);
            exit;
        }

        $encryptedSecret = CryptoHelper::encrypt($secretPlain);
        $userId = (int) $_SESSION['user_id'];
        $a = new ActivityService($db);

        if ($editId) {
            $connModel->updateCredentials($editId, $clientId, $encryptedSecret, $channelType ?: null, $apiBaseUrl);
            if ($storeName !== $existing->store_name) {
                $connModel->rename($editId, $storeName);
            }
            $a->log($userId, 'walmart_store_updated', "Actualizó credenciales de la tienda Walmart ID {$editId} ({$storeName})");
            $_SESSION['success'] = 'Conexión actualizada y verificada correctamente.';
        } else {
            $dup = $connModel->findByClientId($clientId);
            if ($dup) {
                $_SESSION['error'] = 'Ya existe una conexión con ese Client ID.';
                header('Location: ' . $backTo);
                exit;
            }
            $newId = $connModel->create($userId, $storeName, $clientId, $encryptedSecret, $channelType ?: null, $apiBaseUrl);
            $a->log($userId, 'walmart_store_connected', "Conectó la tienda Walmart '{$storeName}' (ID {$newId})");
            $_SESSION['success'] = 'Tienda Walmart conectada y verificada correctamente.';
        }

        header('Location: ' . $this->route('/adminstores'));
        exit;
    }

    public function testConnection($id = null) {
        $this->requireAdmin();
        header('Content-Type: application/json');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['ok' => false, 'error' => 'Método no permitido.']);
            exit;
        }
        $csrf = $_POST['csrf_token'] ?? '';
        if (empty($csrf) || !hash_equals($_SESSION['csrf_token'] ?? '', $csrf)) {
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'Token inválido.']);
            exit;
        }
        if (empty($id) || !is_numeric($id)) {
            echo json_encode(['ok' => false, 'error' => 'ID inválido.']);
            exit;
        }

        $auth = new WalmartAuthService($this->db());
        $token = $auth->getToken((int) $id, true);
        echo json_encode($token
            ? ['ok' => true, 'message' => 'Conexión verificada: token obtenido correctamente.']
            : ['ok' => false, 'error' => 'Walmart rechazó las credenciales o no respondió. Revisa el Client ID/Secret.']);
        exit;
    }

    public function disconnect($id) {
        $this->requireAdmin();
        $this->requirePostCsrf();

        if (empty($id) || !is_numeric($id)) {
            $_SESSION['error'] = 'ID inválido.';
            header('Location: ' . $this->route('/adminstores'));
            exit;
        }

        $db = $this->db();
        (new WalmartConnectionModel($db))->setActive((int) $id, false);
        (new ActivityService($db))->log((int) $_SESSION['user_id'], 'walmart_store_disconnected', "Desactivó la tienda Walmart ID {$id}");
        $_SESSION['success'] = 'Tienda desactivada correctamente.';
        header('Location: ' . $this->route('/adminstores'));
        exit;
    }

    public function reactivate($id) {
        $this->requireAdmin();
        $this->requirePostCsrf();

        if (empty($id) || !is_numeric($id)) {
            $_SESSION['error'] = 'ID inválido.';
            header('Location: ' . $this->route('/adminstores'));
            exit;
        }

        $db = $this->db();
        (new WalmartConnectionModel($db))->setActive((int) $id, true);
        (new ActivityService($db))->log((int) $_SESSION['user_id'], 'walmart_store_reactivated', "Reactivó la tienda Walmart ID {$id}");
        $_SESSION['success'] = 'Tienda reactivada correctamente.';
        header('Location: ' . $this->route('/adminstores'));
        exit;
    }

    public function deleteStore($id) {
        $this->requireAdmin();
        $this->requirePostCsrf();

        if (empty($id) || !is_numeric($id)) {
            $_SESSION['error'] = 'ID inválido.';
            header('Location: ' . $this->route('/adminstores'));
            exit;
        }

        $db = $this->db();
        (new WalmartConnectionModel($db))->delete((int) $id);
        (new ActivityService($db))->log((int) $_SESSION['user_id'], 'walmart_store_deleted', "Eliminó la tienda Walmart ID {$id}");
        $_SESSION['success'] = 'Tienda eliminada permanentemente.';
        header('Location: ' . $this->route('/adminstores'));
        exit;
    }

    public function rename($id) {
        $this->requireAdmin();
        $this->requirePostCsrf();

        if (empty($id) || !is_numeric($id)) {
            $_SESSION['error'] = 'ID inválido.';
            header('Location: ' . $this->route('/adminstores'));
            exit;
        }

        $storeName = trim((string) ($_POST['store_name'] ?? ''));
        if ($storeName === '') {
            $_SESSION['error'] = 'El nombre de la tienda es obligatorio.';
            header('Location: ' . $this->route('/adminstores'));
            exit;
        }

        $db = $this->db();
        $connModel = new WalmartConnectionModel($db);
        $oldName = $connModel->findStoreName((int) $id);
        $connModel->rename((int) $id, $storeName);
        (new ActivityService($db))->log((int) $_SESSION['user_id'], 'walmart_store_renamed', "Renombró tienda Walmart ID {$id}: '{$oldName}' → '{$storeName}'");
        $_SESSION['success'] = 'Tienda renombrada correctamente.';
        header('Location: ' . $this->route('/adminstores'));
        exit;
    }

    // ── Actualización masiva de precios/stock ──

    public function updates() {
        $this->requireAuth();
        $this->ensureCsrf();

        $db = $this->db();
        $service = new WalmartUpdateService($db);
        $pending = $service->restoreBatchFromDb((int) $_SESSION['user_id']);

        $page_title = 'Walmart - Actualizar precios y stock';
        $page_description = 'Sube un archivo con SKU y valor para actualizar en Walmart.';
        $current_nav = 'walmart-updates';

        $data = [
            'csrf_token' => $_SESSION['csrf_token'],
            'connections' => (new WalmartConnectionModel($db))->findActive(),
            'pending_batch' => $pending ? [
                'batch_id' => $pending['batch_id'],
                'update_type' => $pending['update_type'],
                'walmart_connection_id' => $pending['walmart_connection_id'],
                'total' => $pending['total'],
                'processed' => $pending['processed'],
                'ok' => $pending['ok'],
                'errors' => $pending['errors'],
            ] : null,
            'dry_run' => WALMART_DRY_RUN,
        ];

        $view_content = __DIR__ . '/../Views/walmart/content-updates.php';
        require __DIR__ . '/../Views/layouts/app.php';
    }

    public function updateHistory() {
        $this->requireAuth();
        $this->ensureCsrf();

        $page_title = 'Walmart - Historial de actualizaciones';
        $page_description = 'Batches de precios y stock ejecutados contra Walmart.';
        $current_nav = 'walmart-history';

        $data = [
            'csrf_token' => $_SESSION['csrf_token'],
            'is_admin' => !empty($_SESSION['is_admin']),
            'dry_run' => WALMART_DRY_RUN,
        ];

        $view_content = __DIR__ . '/../Views/walmart/content-update-history.php';
        require __DIR__ . '/../Views/layouts/app.php';
    }

    public function updateHistoryData() {
        $this->requireAuth();
        header('Content-Type: application/json');

        $page = isset($_GET['page']) && is_numeric($_GET['page']) ? max(1, (int) $_GET['page']) : 1;
        $type = trim((string) ($_GET['type'] ?? ''));

        $service = new WalmartUpdateService($this->db());
        echo json_encode($service->fetchHistory((int) $_SESSION['user_id'], !empty($_SESSION['is_admin']), $page, 10, $type));
        exit;
    }

    public function updateBatchLogs($batchId = null) {
        $this->requireAuth();
        header('Content-Type: application/json');

        if (empty($batchId) || !preg_match('/^[a-f0-9]{16}$/', $batchId)) {
            echo json_encode(['error' => 'Batch inválido.']);
            exit;
        }

        $service = new WalmartUpdateService($this->db());
        echo json_encode(['logs' => $service->fetchBatchLogs($batchId, (int) $_SESSION['user_id'], !empty($_SESSION['is_admin']))]);
        exit;
    }

    public function prepareUpdate() {
        $this->requireAuth();
        header('Content-Type: application/json');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['ok' => false, 'error' => 'Método no permitido.']);
            exit;
        }
        $csrf = $_POST['csrf_token'] ?? '';
        if (empty($csrf) || !hash_equals($_SESSION['csrf_token'] ?? '', $csrf)) {
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'Token inválido.']);
            exit;
        }

        $storeId = isset($_POST['store_id']) && is_numeric($_POST['store_id']) ? (int) $_POST['store_id'] : 0;
        $type = ($_POST['update_type'] ?? '') === 'stock' ? 'stock' : 'price';

        $conn = (new WalmartConnectionModel($this->db()))->findById($storeId);
        if (!$conn || !$conn->is_active) {
            echo json_encode(['ok' => false, 'error' => 'Tienda inválida o inactiva.']);
            exit;
        }

        if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            echo json_encode(['ok' => false, 'error' => 'No se recibió el archivo.']);
            exit;
        }
        $file = $_FILES['file'];
        if ($file['size'] > 10 * 1024 * 1024) {
            echo json_encode(['ok' => false, 'error' => 'El archivo excede 10 MB.']);
            exit;
        }
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['xlsx', 'csv'])) {
            echo json_encode(['ok' => false, 'error' => 'Formato no soportado. Usa .xlsx o .csv.']);
            exit;
        }
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($file['tmp_name']);
        $allowedMimes = [
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/zip', 'application/octet-stream',
            'text/plain', 'text/csv', 'application/csv',
        ];
        if (!in_array($mime, $allowedMimes)) {
            echo json_encode(['ok' => false, 'error' => 'Tipo de archivo no permitido (' . $mime . ').']);
            exit;
        }

        try {
            $service = new WalmartUpdateService($this->db());
            $rows = $service->readRows($file['tmp_name'], $ext);
            $parsed = $service->parseEntries($rows, $type);
        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
            exit;
        }

        if (empty($parsed['entries'])) {
            echo json_encode([
                'ok' => false,
                'error' => 'El archivo no contiene filas válidas.',
                'validation_errors' => $parsed['validation_errors'],
            ]);
            exit;
        }

        $batch = $service->createBatch((int) $_SESSION['user_id'], $storeId, $type, $parsed['entries']);

        if (!empty($parsed['validation_errors'])) {
            try {
                (new NotificationService($this->db()))->notifyImportWarning((int) $_SESSION['user_id'], null, count($parsed['validation_errors']));
            } catch (Exception $e) {}
        }

        echo json_encode([
            'ok' => true,
            'batch_id' => $batch['batch_id'],
            'update_type' => $type,
            'total' => $batch['total'],
            'validation_errors' => $parsed['validation_errors'],
            'preview' => array_slice($parsed['entries'], 0, 20),
        ]);
        exit;
    }

    public function applyUpdateBatch() {
        $this->requireAuth();
        header('Content-Type: application/json');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['ok' => false, 'error' => 'Método no permitido.']);
            exit;
        }
        $csrf = $_POST['csrf_token'] ?? '';
        if (empty($csrf) || !hash_equals($_SESSION['csrf_token'] ?? '', $csrf)) {
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'Token inválido.']);
            exit;
        }

        $userId = (int) $_SESSION['user_id'];
        $db = $this->db();
        $service = new WalmartUpdateService($db);
        $batch = $service->restoreBatchFromDb($userId);
        if (!$batch) {
            echo json_encode(['ok' => false, 'error' => 'No hay un batch pendiente.']);
            exit;
        }

        $result = $service->processNextChunk($userId, $batch, 10);

        if (!empty($result['error'])) {
            echo json_encode(['ok' => false, 'error' => $result['error'], 'done' => true]);
            exit;
        }

        if ($result['done']) {
            $service->deleteBatchFromDb($userId);
            $typeLabel = $batch['update_type'] === 'stock' ? 'stock' : 'precios';
            try {
                (new NotificationService($db))->notifyPriceBatchDone($userId, null, $result['ok'], $result['errors']);
            } catch (Exception $e) {}
            try {
                (new ActivityService($db))->log($userId, 'walmart_bulk_update', "Batch de {$typeLabel} Walmart {$batch['batch_id']}: {$result['ok']} OK, {$result['errors']} errores de {$result['total']}");
            } catch (Exception $e) {}
        }

        echo json_encode([
            'ok' => true,
            'done' => $result['done'],
            'processed' => $result['processed'],
            'total' => $result['total'],
            'ok_count' => $result['ok'],
            'error_count' => $result['errors'],
            'results' => $result['results'],
        ]);
        exit;
    }

    public function cancelUpdateBatch() {
        $this->requireAuth();
        header('Content-Type: application/json');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['ok' => false, 'error' => 'Método no permitido.']);
            exit;
        }
        $csrf = $_POST['csrf_token'] ?? '';
        if (empty($csrf) || !hash_equals($_SESSION['csrf_token'] ?? '', $csrf)) {
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'Token inválido.']);
            exit;
        }

        $userId = (int) $_SESSION['user_id'];
        $service = new WalmartUpdateService($this->db());
        $service->deleteBatchFromDb($userId);
        try {
            (new ActivityService($this->db()))->log($userId, 'walmart_bulk_update', 'Canceló el batch de actualización Walmart pendiente');
        } catch (Exception $e) {}
        echo json_encode(['ok' => true]);
        exit;
    }
}
