<?php

/**
 * Autenticación contra la API de Cencosud Chile (OAuth 2.0 client_credentials).
 *
 * Cada conexión guarda su Client ID/Secret (cifrado) y el token de acceso
 * se solicita bajo demanda a POST /v3/token y se almacena cacheado
 * y cifrado en cencosud_connections (access_token + token_expires_at).
 */
class CencosudAuthService {

    /** Margen en segundos antes de la expiración para renovar el token. */
    private const RENEW_MARGIN = 60;

    private $db;
    private $connection;

    public function __construct($db) {
        $this->db = $db;
        $this->connection = new CencosudConnectionModel($db);
    }

    /**
     * Devuelve un token válido para la conexión, renovándolo si está por
     * vencer (o si $forceNew, por ejemplo, tras recibir un error 401).
     * Retorna null si falla.
     */
    public function getToken($connectionId, $forceNew = false) {
        $conn = $this->connection->findById($connectionId);
        if (!$conn || (isset($conn->is_active) && (int)$conn->is_active !== 1)) {
            error_log("[CENCOSUD-AUTH] Conexión {$connectionId}: no encontrada o desactivada en BD");
            return null;
        }

        // Si no se fuerza token nuevo y el token cacheado es válido, usarlo
        if (!$forceNew && $conn->access_token && $conn->token_expires_at
            && strtotime($conn->token_expires_at . ' UTC') > time() + self::RENEW_MARGIN) {
            $token = CryptoHelper::decrypt($conn->access_token);
            if ($token) return $token;
        }

        // Solicitar un nuevo token a la API
        $result = $this->requestToken($conn);
        $body = $result['body'] ?? null;
        $token = null;

        if (is_object($body)) {
            if (!empty($body->accessToken) && is_string($body->accessToken)) {
                $token = trim($body->accessToken);
            } elseif (!empty($body->access_token) && is_string($body->access_token)) {
                $token = trim($body->access_token);
            }
        }

        // Validación estricta: Rechazar respuestas sin token o con código distinto a HTTP 200
        if ($result['code'] !== 200 || empty($token)) {
            error_log("[CENCOSUD-AUTH] Conexión {$connectionId}: obtención de token FALLÓ — HTTP " . ($result['code'] ?? '?')
                . ' — ' . substr((string) ($result['raw'] ?? ''), 0, 300));
            return null;
        }

        $expiresIn = (int) ($body->expiresIn ?? ($body->expires_in ?? 14400));
        if ($expiresIn < 60) $expiresIn = 14400; // Valor seguro por defecto (4 horas Cencosud)
        
        // Guardar la expiración en UTC restándole un pequeño margen de seguridad
        $expiresAt = (new DateTime('now', new DateTimeZone('UTC')))
            ->setTimestamp(time() + max(60, $expiresIn - 30))
            ->format('Y-m-d H:i:s');
            
        $this->connection->updateToken($connectionId, CryptoHelper::encrypt($token), $expiresAt);
        return $token;
    }

    /**
     * Valida credenciales solicitando un token real (o simulado en dry-run),
     * sin persistir nada en la base de datos.
     * Retorna ['ok' => bool, 'error' => ?string].
     */
    public function testCredentials($clientId, $clientSecret, $baseUrl = null, $channelType = null) {
        $clientId = trim((string) $clientId);
        $clientSecret = trim((string) $clientSecret);
        if ($clientId === '' || $clientSecret === '') {
            return ['ok' => false, 'error' => 'Client ID y Client Secret son obligatorios.'];
        }

        $result = CencosudApiHelper::request(
            $baseUrl ?: CENCOSUD_API_BASE_URL,
            '/v3/token',
            'POST',
            ['grant_type' => 'client_credentials'],
            ['client_id' => $clientId, 'client_secret' => $clientSecret, 'channel_type' => $channelType, 'market' => 'cl']
        );

        $body = $result['body'] ?? null;
        $token = (is_object($body) && (!empty($body->accessToken) || !empty($body->access_token))) 
            ? ($body->accessToken ?? $body->access_token) 
            : null;

        if ($result['code'] === 200 && !empty($token)) {
            return ['ok' => true, 'error' => null];
        }
        if ($result['code'] === 401 || $result['code'] === 400) {
            return ['ok' => false, 'error' => 'Credenciales rechazadas por Cencosud (HTTP ' . $result['code'] . '). Verifica Client ID y Secret.'];
        }
        if ($result['code'] === 0) {
            return ['ok' => false, 'error' => 'No se pudo contactar la API de Cencosud (error de red).'];
        }
        return ['ok' => false, 'error' => 'Respuesta inesperada de Cencosud (HTTP ' . $result['code'] . ').'];
    }

    /** Datos de autenticación estructurados para CencosudApiHelper::request(). */
    public function buildAuth($conn, $token = null) {
        return [
            'client_id' => $conn->client_id,
            'client_secret' => CryptoHelper::decrypt($conn->client_secret),
            'token' => $token,
            'channel_type' => $conn->channel_type ?: null,
            'market' => $conn->market ?: 'cl',
        ];
    }

    private function requestToken($conn) {
        return CencosudApiHelper::request(
            $conn->api_base_url ?: CENCOSUD_API_BASE_URL,
            '/v3/token',
            'POST',
            ['grant_type' => 'client_credentials'],
            $this->buildAuth($conn)
        );
    }
}
